module.exports = {
    token: "mfa.JxN9_JCyqSjrC6_Qw17r-Ws81sBNt0VFJqqgKOxJ3JrhMfbhj162c7zw746Eor47KAT-b4OIk7jUel9lFZUE",
    prefix: "**"
};

/* remove .example from the name of this file */